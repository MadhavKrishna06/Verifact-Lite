# VERIFACT-Lite: before / after example

## QUESTION
Why would a supersonic airliner like Concorde be uneconomical to operate today?

## ORIGINAL ANSWER
The Concorde was uneconomical to operate today due to a combination of factors, including its extremely high operating costs. The aircraft consumed approximately 3 times more fuel per seat compared to conventional subsonic airliners, which, at twice the speed, resulted in significantly greater fuel burn. This efficiency penalty was exacerbated by the Concorde's complex supersonic aerodynamics, requiring specially designed engines and materials that added considerable weight and maintenance costs. Moreover, the introduction of more efficient, quieter, and faster aircraft like the Airbus A380 and Boeing 787, coupled with increased fuel efficiency and reduced operating costs, made the Concorde's economic viability untenable. Additionally, the Concorde's market was limited by its ability to fly non-stop to only 18 destinations, making it less attractive for airlines seeking profitable routes. These factors, including the Concorde's high operating costs and limited market, rendered it uneconomical to operate as an airliner today.

## BASELINE FACTS
- The Concorde was uneconomical to operate.
- The Concorde was uneconomical to operate today.
- There were a combination of factors.
- The combination of factors included extremely high operating costs.
- The aircraft consumed more fuel.
- The aircraft consumed approximately 3 times more fuel per seat.
- Conventional subsonic airliners consumed less fuel.
- Conventional subsonic airliners were used as a comparison.
- Conventional subsonic airliners consumed less fuel per seat.
- The aircraft consumed more fuel at twice the speed.
- The aircraft consumed significantly more fuel.
- The aircraft consumed significantly more fuel per seat.

## DETECTED ISSUES AND REFINEMENTS
- **F3** (ambiguous_concept_or_pronoun)
  - baseline: There were a combination of factors.
  - reason:   The claim uses 'a combination of factors' which refers to the factors mentioned in the context but is vague without specifying them.
  - refined:  The Concorde's high operating costs, including its fuel consumption and complex aerodynamics, made it uneconomical to operate today.
- **F5** (missing_comparison)
  - baseline: The aircraft consumed more fuel.
  - reason:   The claim says 'more fuel' without specifying the comparison target from the context.
  - refined:  The Concorde consumed more fuel per seat compared to conventional subsonic airliners.
- **F7** (missing_comparison)
  - baseline: Conventional subsonic airliners consumed less fuel.
  - reason:   The claim states 'consumed less fuel' without specifying the comparison target, which is 'Concorde' in the context.
  - refined:  Conventional subsonic airliners consumed less fuel per seat compared to the Concorde.
- **F8** (missing_comparison)
  - baseline: Conventional subsonic airliners were used as a comparison.
  - reason:   The claim implies a comparison but does not specify what was used as a comparison.
  - refined:  The Concorde was uneconomical to operate today compared to conventional subsonic airliners, which consumed less fuel per seat.
- **F9** (missing_comparison)
  - baseline: Conventional subsonic airliners consumed less fuel per seat.
  - reason:   The claim states 'consumed less fuel per seat' without the comparison target from the context.
  - refined:  Conventional subsonic airliners consumed less fuel per seat compared to the Concorde.
- **F10** (missing_comparison)
  - baseline: The aircraft consumed more fuel at twice the speed.
  - reason:   The claim states 'twice the speed' without mentioning the fuel consumption comparison.
  - refined:  The aircraft consumed more fuel at twice the speed compared to conventional subsonic airliners.
- **F11** (missing_comparison)
  - baseline: The aircraft consumed significantly more fuel.
  - reason:   The claim says 'significantly more fuel' without specifying the comparison target from the context.
  - refined:  The Concorde consumed significantly more fuel per seat compared to conventional subsonic airliners.
- **F12** (missing_comparison)
  - baseline: The aircraft consumed significantly more fuel per seat.
  - reason:   The claim says 'significantly more fuel per seat' without the comparison target from the context.
  - refined:  The Concorde consumed significantly more fuel per seat compared to conventional subsonic airliners.
- **F13** (omitted_condition_or_source)
  - baseline: This efficiency penalty exists.
  - reason:   The claim omits the specific condition and context of the Concorde's high fuel consumption compared to subsonic airliners.
  - refined:  The Concorde's high fuel consumption per seat compared to conventional subsonic airliners made its operation uneconomical today.
- **F15** (omitted_condition_or_source)
  - baseline: The Concorde requires specially designed engines.
  - reason:   The claim omits the condition that the Concorde requires specially designed engines due to its supersonic aerodynamics.
  - refined:  The Concorde requires specially designed engines due to its supersonic aerodynamics.
- **F16** (omitted_condition_or_source)
  - baseline: The Concorde requires specially designed materials.
  - reason:   The claim omits the condition 'due to its complex supersonic aerodynamics' stated in the context.
  - refined:  The Concorde requires specially designed materials due to its complex supersonic aerodynamics.
- **F17** (omitted_condition_or_source)
  - baseline: The specially designed engines add considerable weight.
  - reason:   The claim omits the condition that the engines are 'supersonic' and the context for 'considerable weight'.
  - refined:  The specially designed supersonic engines for the Concorde add considerable weight.
- **F18** (omitted_condition_or_source)
  - baseline: The specially designed materials add considerable weight.
  - reason:   The claim omits the condition that the specially designed materials add considerable weight due to supersonic aerodynamics.
  - refined:  The specially designed materials add considerable weight because of the aircraft's supersonic aerodynamics.
- **F19** (omitted_condition_or_source)
  - baseline: The specially designed engines and materials add considerable maintenance costs.
  - reason:   The claim omits the specific context about the Concorde's supersonic aerodynamics.
  - refined:  The specially designed engines and materials for the Concorde's supersonic aerodynamics add considerable maintenance costs.
- **F20** (missing_comparison)
  - baseline: More efficient, quieter, and faster aircraft like the Airbus A380 and Boeing 787 were introduced.
  - reason:   The claim implies a comparison but omits the comparison target stated in the context.
  - refined:  The introduction of more efficient, quieter, and faster aircraft like the Airbus A380 and Boeing 787 made the Concorde's economic viability untenable.
- **F21** (missing_comparison)
  - baseline: Increased fuel efficiency and reduced operating costs occurred.
  - reason:   The claim implies a comparison but omits the target of comparison stated in the context.
  - refined:  Increased fuel efficiency and reduced operating costs occurred compared to the Concorde.
- **F22** (omitted_condition_or_source)
  - baseline: The introduction of these aircraft made the Concorde's economic viability untenable.
  - reason:   The claim omits the specific types of aircraft (Airbus A380 and Boeing 787) and the factors (increased fuel efficiency and reduced operating costs) that made the Concorde's economic viability untenable.
  - refined:  The introduction of the Airbus A380 and Boeing 787, coupled with increased fuel efficiency and reduced operating costs, made the Concorde's economic viability untenable.
- **F23** (omitted_condition_or_source)
  - baseline: The Concorde had a limited market.
  - reason:   The claim omits the specific condition and context provided in the context.
  - refined:  The Concorde's limited market was a condition that made it uneconomical to operate as an airliner today.
- **F24** (omitted_condition_or_source)
  - baseline: The Concorde's market was limited by its ability to fly non-stop.
  - reason:   The claim omits the specific number of destinations (18) and the context of non-stop flights.
  - refined:  The Concorde's market was limited by its ability to fly non-stop to only 18 destinations.
- **F25** (omitted_condition_or_source)
  - baseline: The Concorde could fly to only 18 destinations.
  - reason:   The claim omits the condition 'non-stop' stated in the context.
  - refined:  The Concorde could fly to only 18 destinations non-stop.
- **F26** (omitted_condition_or_source)
  - baseline: The number of destinations limited the Concorde's market.
  - reason:   The claim omits the specific condition that the Concorde could fly non-stop to only 18 destinations.
  - refined:  The number of destinations (only 18 non-stop flights) limited the Concorde's market.
- **F27** (omitted_condition_or_source)
  - baseline: Airlines found the Concorde less attractive.
  - reason:   The claim omits the specific conditions and factors that made the Concorde less attractive to airlines, as stated in the context.
  - refined:  The Concorde's high operating costs and limited market made it less attractive to airlines today.
- **F28** (omitted_condition_or_source)
  - baseline: Airlines sought profitable routes.
  - reason:   The claim omits the condition that the airlines sought profitable routes due to the Concorde's limited market.
  - refined:  The Concorde's limited market made it less attractive for airlines seeking profitable routes.
- **F29** (omitted_condition_or_source)
  - baseline: The Concorde was less attractive for airlines seeking profitable routes.
  - reason:   The claim omits the specific condition of 'limited market' stated in the context.
  - refined:  The Concorde was less attractive for airlines seeking profitable routes compared to more efficient aircraft.
- **F30** (ambiguous_concept_or_pronoun)
  - baseline: These factors exist.
  - reason:   The claim uses 'these factors' without specifying what they refer to.
  - refined:  These factors make the Concorde uneconomical to operate today.
- **F31** (omitted_condition_or_source)
  - baseline: These factors include the Concorde's high operating costs.
  - reason:   The claim drops the 'due to a combination of factors' condition it depends on.
  - refined:  These factors include the Concorde's high operating costs, due to a combination of factors.
- **F32** (omitted_condition_or_source)
  - baseline: These factors include the Concorde's limited market.
  - reason:   The claim omits the specific context that these factors include the Concorde's limited market, which is part of the overall explanation for its uneconomical operation.
  - refined:  These factors include the Concorde's limited market, making it less attractive for airlines seeking profitable routes.
- **F33** (omitted_condition_or_source)
  - baseline: These factors make the Concorde uneconomical.
  - reason:   The claim omits the specific context of 'today' and the factors mentioned in the context.
  - refined:  These factors make the Concorde uneconomical to operate today.

## MISSING RELATIONS (word mapping -> judges)
- span `which, at twice the speed, resulted in significantly greater fuel burn` -> contingency
- span `was exacerbated by the Concorde` -> contingency
- span `and maintenance costs` -> contingency
- span `Moreover, the introduction of` -> contingency
- span `and limited market, rendered it uneconomical to operat` -> contingency

## ADDED FACTS
- [contingency] The aircraft consumed significantly more fuel, which resulted in the efficiency penalty, making the Concorde uneconomical to operate today.
- [contingency] The efficiency penalty resulting from the Concorde's complex supersonic aerodynamics and specially designed engines and materials, exacerbated by the introduction of more efficient aircraft, made the Concorde uneconomical to operate today.
- [contingency] The high operating costs and limited market of the Concorde resulted in its uneconomical operation today.
- [contingency] The introduction of more efficient, quieter, and faster aircraft resulted in the Concorde's economic viability becoming untenable.
- [contingency] The limited market and high operating costs resulted in the Concorde being uneconomical to operate today.

## VERIFICATION BEFORE VS AFTER REFINEMENT
- F3: UNDECIDED -> SUPPORTED
  - before: There were a combination of factors.
  - after:  The Concorde's high operating costs, including its fuel consumption and complex aerodynamics, made it uneconomical to operate today.
- F7: SUPPORTED -> UNDECIDED
  - before: Conventional subsonic airliners consumed less fuel.
  - after:  Conventional subsonic airliners consumed less fuel per seat compared to the Concorde.
- F8: UNDECIDED -> SUPPORTED
  - before: Conventional subsonic airliners were used as a comparison.
  - after:  The Concorde was uneconomical to operate today compared to conventional subsonic airliners, which consumed less fuel per seat.
- F9: SUPPORTED -> UNDECIDED
  - before: Conventional subsonic airliners consumed less fuel per seat.
  - after:  Conventional subsonic airliners consumed less fuel per seat compared to the Concorde.
- F11: UNDECIDED -> SUPPORTED
  - before: The aircraft consumed significantly more fuel.
  - after:  The Concorde consumed significantly more fuel per seat compared to conventional subsonic airliners.
- F12: UNDECIDED -> SUPPORTED
  - before: The aircraft consumed significantly more fuel per seat.
  - after:  The Concorde consumed significantly more fuel per seat compared to conventional subsonic airliners.
- F13: UNDECIDED -> SUPPORTED
  - before: This efficiency penalty exists.
  - after:  The Concorde's high fuel consumption per seat compared to conventional subsonic airliners made its operation uneconomical today.
- F15: SUPPORTED -> UNDECIDED
  - before: The Concorde requires specially designed engines.
  - after:  The Concorde requires specially designed engines due to its supersonic aerodynamics.
- F20: UNDECIDED -> SUPPORTED
  - before: More efficient, quieter, and faster aircraft like the Airbus A380 and Boeing 787 were introduced.
  - after:  The introduction of more efficient, quieter, and faster aircraft like the Airbus A380 and Boeing 787 made the Concorde's economic viability untenable.
- F21: UNDECIDED -> SUPPORTED
  - before: Increased fuel efficiency and reduced operating costs occurred.
  - after:  Increased fuel efficiency and reduced operating costs occurred compared to the Concorde.
- F22: UNDECIDED -> SUPPORTED
  - before: The introduction of these aircraft made the Concorde's economic viability untenable.
  - after:  The introduction of the Airbus A380 and Boeing 787, coupled with increased fuel efficiency and reduced operating costs, made the Concorde's economic viability untenable.
- F24: SUPPORTED -> UNDECIDED
  - before: The Concorde's market was limited by its ability to fly non-stop.
  - after:  The Concorde's market was limited by its ability to fly non-stop to only 18 destinations.
- F26: SUPPORTED -> UNDECIDED
  - before: The number of destinations limited the Concorde's market.
  - after:  The number of destinations (only 18 non-stop flights) limited the Concorde's market.
- F33: SUPPORTED -> UNDECIDED
  - before: These factors make the Concorde uneconomical.
  - after:  These factors make the Concorde uneconomical to operate today.

## METRICS (whole mini benchmark)

| System | Precision | Recall | F1 |
|---|---|---|---|
| Baseline | 0.4200 | 0.4077 | 0.4138 |
| VERIFACT-Lite | 0.3018 | 0.4077 | 0.3468 |
