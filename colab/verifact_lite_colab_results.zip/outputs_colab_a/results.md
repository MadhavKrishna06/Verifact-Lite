_These numbers were measured by this repository on the mini reference benchmark. They are not the paper's numbers and are not comparable to them._

Questions: **12** &nbsp;|&nbsp; reference facts: **86**

### Baseline vs VERIFACT-Lite

| Metric | Baseline | VERIFACT-Lite | Delta |
|---|---|---|---|
| questions | 12 | 12 | +0 |
| avg_facts_per_answer | 21.5000 | 25.3333 | +3.8333 |
| incomplete_facts | 113 | 125 | +12 |
| incomplete_fact_rate | 0.4380 | 0.4112 | -0.0268 |
| missing_relations | 54 | 0 | -54 |
| candidate_spans | 73 | 73 | +0 |
| refined_facts | 0 | 143 | +143 |
| added_facts | 0 | 52 | +52 |
| supported | 109 | 95 | -14 |
| contradicted | 3 | 8 | +5 |
| undecided | 146 | 201 | +55 |
| precision | 0.4200 | 0.3018 | -0.1182 |
| decided_precision | 0.9732 | 0.9223 | -0.0509 |
| recall | 0.4077 | 0.4077 | +0.0000 |
| f1 | 0.4138 | 0.3468 | -0.0669 |
| reference_facts | 86 | 86 | +0 |
| covered_reference_facts | 35 | 35 | +0 |

### Improvement

- incomplete fact reduction: **6.1%**
- missing relation reduction: **100.0%**
- precision change: **-0.1182**
- recall change: **+0.0000**
- F1 change: **-0.0669**

### Ablation

| System | Incomplete rate | Missing relations | Precision | Recall | F1 |
|---|---|---|---|---|---|
| Baseline | 0.438 | 54 | 0.4200 | 0.4077 | 0.4138 |
| + Incomplete Refine | 0.373 | 54 | 0.3125 | 0.4077 | 0.3538 |
| + Missing Relation | 0.465 | 0 | 0.3888 | 0.4077 | 0.3980 |
| Full VERIFACT-Lite | 0.411 | 0 | 0.3018 | 0.4077 | 0.3468 |

### Judge ablation (single judge vs union ensemble)

| Judge | Incomplete detected | Missing relations detected | Problem-detection recall vs ensemble | Precision vs ensemble |
|---|---|---|---|---|
| qwen | 32 | 15 | 0.540 | 1.000 |
| llama | 27 | 54 | 0.931 | 1.000 |
| ensemble | 33 | 54 | 1.000 | 1.000 |

### Ensemble strategy: union vs majority vote

Both rows use the same judge decisions; only the rule that turns them into a refinement decision differs. Union is the paper's rule.

| Strategy | Incomplete rate | Missing relations | Precision | Recall | F1 |
|---|---|---|---|---|---|
| union | 0.411 | 0 | 0.3018 | 0.4077 | 0.3468 |
| majority | 0.393 | 0 | 0.4106 | 0.4077 | 0.4092 |

### Before vs after verification of refined facts

- refined facts verified both ways: **149**
- label changes: **68**
- label change rate: **0.456**

| Transition | Count |
|---|---|
| UNDECIDED->UNDECIDED | 60 |
| SUPPORTED->UNDECIDED | 42 |
| UNDECIDED->SUPPORTED | 21 |
| SUPPORTED->SUPPORTED | 20 |
| SUPPORTED->CONTRADICTED | 4 |
| CONTRADICTED->UNDECIDED | 1 |
| CONTRADICTED->CONTRADICTED | 1 |

### Charts

![incomplete_fact_rate](/content/verifact-lite/outputs_colab_a/charts/incomplete_fact_rate.png)
![missing_facts](/content/verifact-lite/outputs_colab_a/charts/missing_facts.png)
![precision_recall_f1](/content/verifact-lite/outputs_colab_a/charts/precision_recall_f1.png)
![ablation](/content/verifact-lite/outputs_colab_a/charts/ablation.png)
