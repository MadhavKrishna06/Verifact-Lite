_These numbers were measured by this repository on the mini reference benchmark. They are not the paper's numbers and are not comparable to them._

Questions: **12** &nbsp;|&nbsp; reference facts: **86**

### Baseline vs VERIFACT-Lite

| Metric | Baseline | VERIFACT-Lite | Delta |
|---|---|---|---|
| questions | 12 | 12 | +0 |
| avg_facts_per_answer | 15.9167 | 17.5000 | +1.5833 |
| incomplete_facts | 61 | 60 | -1 |
| incomplete_fact_rate | 0.3194 | 0.2857 | -0.0337 |
| missing_relations | 21 | 0 | -21 |
| candidate_spans | 32 | 32 | +0 |
| refined_facts | 0 | 69 | +69 |
| added_facts | 0 | 21 | +21 |
| supported | 99 | 103 | +4 |
| contradicted | 1 | 2 | +1 |
| undecided | 91 | 105 | +14 |
| precision | 0.5050 | 0.4802 | -0.0248 |
| decided_precision | 0.9900 | 0.9810 | -0.0090 |
| recall | 0.2812 | 0.2812 | +0.0000 |
| f1 | 0.3613 | 0.3547 | -0.0066 |
| reference_facts | 86 | 86 | +0 |
| covered_reference_facts | 24 | 24 | +0 |

### Improvement

- incomplete fact reduction: **10.5%**
- missing relation reduction: **100.0%**
- precision change: **-0.0248**
- recall change: **+0.0000**
- F1 change: **-0.0066**

### Ablation

| System | Incomplete rate | Missing relations | Precision | Recall | F1 |
|---|---|---|---|---|---|
| Baseline | 0.319 | 21 | 0.5050 | 0.2812 | 0.3613 |
| + Incomplete Refine | 0.265 | 21 | 0.4948 | 0.2812 | 0.3586 |
| + Missing Relation | 0.335 | 0 | 0.4884 | 0.2812 | 0.3570 |
| Full VERIFACT-Lite | 0.286 | 0 | 0.4802 | 0.2812 | 0.3547 |

### Judge ablation (single judge vs union ensemble)

| Judge | Incomplete detected | Missing relations detected | Problem-detection recall vs ensemble | Precision vs ensemble |
|---|---|---|---|---|
| qwen | 24 | 8 | 0.696 | 1.000 |
| llama | 18 | 21 | 0.848 | 1.000 |
| ensemble | 25 | 21 | 1.000 | 1.000 |

### Ensemble strategy: union vs majority vote

Both rows use the same judge decisions; only the rule that turns them into a refinement decision differs. Union is the paper's rule.

| Strategy | Incomplete rate | Missing relations | Precision | Recall | F1 |
|---|---|---|---|---|---|
| union | 0.286 | 0 | 0.4802 | 0.2812 | 0.3547 |
| majority | 0.287 | 0 | 0.4985 | 0.2812 | 0.3596 |

### Before vs after verification of refined facts

- refined facts verified both ways: **75**
- label changes: **26**
- label change rate: **0.347**

| Transition | Count |
|---|---|
| UNDECIDED->UNDECIDED | 27 |
| SUPPORTED->SUPPORTED | 22 |
| SUPPORTED->UNDECIDED | 13 |
| UNDECIDED->SUPPORTED | 12 |
| SUPPORTED->CONTRADICTED | 1 |

### Charts

![incomplete_fact_rate](/content/verifact-lite/outputs_colab_b/charts/incomplete_fact_rate.png)
![missing_facts](/content/verifact-lite/outputs_colab_b/charts/missing_facts.png)
![precision_recall_f1](/content/verifact-lite/outputs_colab_b/charts/precision_recall_f1.png)
![ablation](/content/verifact-lite/outputs_colab_b/charts/ablation.png)
