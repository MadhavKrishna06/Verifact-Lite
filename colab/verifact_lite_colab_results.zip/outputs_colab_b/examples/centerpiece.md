# VERIFACT-Lite: before / after example

## QUESTION
Why would a supersonic airliner like Concorde be uneconomical to operate today?

## ORIGINAL ANSWER
The Concorde was uneconomical to operate today due to a combination of factors, including its extremely high operating costs. The aircraft consumed approximately 3 times more fuel per seat compared to conventional subsonic airliners, which, at twice the speed, resulted in significantly greater fuel burn. This efficiency penalty was exacerbated by the Concorde's complex supersonic aerodynamics, requiring specially designed engines and materials that added considerable weight and maintenance costs. Moreover, the introduction of more efficient, quieter, and faster aircraft like the Airbus A380 and Boeing 787, coupled with increased fuel efficiency and reduced operating costs, made the Concorde's economic viability untenable. Additionally, the Concorde's market was limited by its ability to fly non-stop to only 18 destinations, making it less attractive for airlines seeking profitable routes. These factors, including the Concorde's high operating costs and limited market, rendered it uneconomical to operate as an airliner today.

## BASELINE FACTS
- The Concorde is uneconomical to operate today.
- The uneconomical operation of the Concorde is due to a combination of factors.
- One factor contributing to the uneconomical operation of the Concorde is its extremely high operating costs, including its approximately 3 times greater fuel consumption per seat compared to conventional subsonic airliners.
- The Concorde consumed approximately 3 times more fuel per seat.
- The Concorde is compared to conventional subsonic airliners.
- Conventional subsonic airliners consume less fuel per seat compared to the Concorde, which consumed approximately 3 times more fuel per seat.
- The Concorde travels at twice the speed of conventional subsonic airliners.
- The aircraft consumed approximately 3 times more fuel per seat compared to conventional subsonic airliners, which, at twice the speed, resulted in significantly greater fuel burn.
- The Concorde's supersonic aerodynamics caused an efficiency penalty, resulting in approximately 3 times more fuel consumption per seat compared to conventional subsonic airliners.
- The Concorde required specially designed engines and materials that added considerable weight and maintenance costs.
- The Concorde required specially designed engines and materials.
- The specially designed engines and materials added considerable weight.

## DETECTED ISSUES AND REFINEMENTS
- **F1** (omitted_condition_or_source)
  - baseline: The Concorde is uneconomical to operate today.
  - reason:   The claim omits the 'due to a combination of factors' condition stated in the context.
  - refined:  The Concorde is uneconomical to operate today due to a combination of factors, including its extremely high operating costs.
- **F5** (missing_comparison)
  - baseline: The Concorde is compared to conventional subsonic airliners.
  - reason:   The claim implies a comparison but does not specify the comparison target as stated in the context.
  - refined:  The Concorde consumed approximately 3 times more fuel per seat compared to conventional subsonic airliners.
- **F10** (omitted_condition_or_source)
  - baseline: The Concorde required specially designed engines and materials that added considerable weight and maintenance costs.
  - reason:   The claim omits the condition 'due to its supersonic aerodynamics' stated in the context.
  - refined:  The Concorde required specially designed engines and materials due to its supersonic aerodynamics, adding considerable weight and maintenance costs.
- **F11** (omitted_condition_or_source)
  - baseline: The Concorde required specially designed engines and materials.
  - reason:   The claim omits the condition 'due to its supersonic aerodynamics' stated in the context.
  - refined:  The Concorde required specially designed engines and materials due to its supersonic aerodynamics.
- **F12** (omitted_condition_or_source)
  - baseline: The specially designed engines and materials added considerable weight.
  - reason:   The claim omits the condition 'due to the Concorde's complex supersonic aerodynamics'.
  - refined:  The specially designed engines and materials added considerable weight due to the Concorde's complex supersonic aerodynamics.
- **F13** (omitted_condition_or_source)
  - baseline: The specially designed engines and materials that added considerable weight exacerbated the Concorde's efficiency penalty.
  - reason:   The claim omits the specific context about supersonic aerodynamics contributing to the efficiency penalty.
  - refined:  The specially designed engines and materials for supersonic aerodynamics added considerable weight, exacerbating the Concorde's efficiency penalty.
- **F14** (omitted_condition_or_source)
  - baseline: The specially designed engines added considerable maintenance costs.
  - reason:   The claim omits the specific condition that the engines are 'supersonic' and the context for why they add maintenance costs.
  - refined:  The specially designed supersonic engines added considerable maintenance costs.
- **F15** (omitted_condition_or_source)
  - baseline: The specially designed engines and materials added considerable maintenance costs.
  - reason:   The claim omits the specific context about supersonic aerodynamics that led to the need for specially designed engines and materials.
  - refined:  The specially designed engines and materials for supersonic aerodynamics added considerable maintenance costs.
- **F16** (missing_comparison)
  - baseline: More efficient aircraft like the Airbus A380 and Boeing 787 were introduced.
  - reason:   The claim implies a comparison but omits the comparison target stated in the context.
  - refined:  More efficient aircraft like the Airbus A380 and Boeing 787 were introduced, reducing the Concorde's economic viability.
- **F17** (missing_comparison)
  - baseline: Quieter and more efficient aircraft like the Airbus A380 and Boeing 787 were introduced.
  - reason:   The claim implies a comparison but omits the comparison target stated in the context.
  - refined:  Quieter and more efficient aircraft like the Airbus A380 and Boeing 787 were introduced, which were more economical to operate.
- **F18** (missing_comparison)
  - baseline: Faster aircraft like the Airbus A380 and Boeing 787 were introduced.
  - reason:   The claim implies a comparison but omits the comparison target stated in the context.
  - refined:  Faster aircraft like the Airbus A380 and Boeing 787 were introduced, which were more efficient and quieter.
- **F19** (missing_comparison)
  - baseline: The Airbus A380 is an efficient aircraft.
  - reason:   The claim states 'efficient' without specifying the comparison target, which is provided in the context.
  - refined:  The Airbus A380 is more efficient compared to the Concorde.
- **F20** (other)
  - baseline: The Boeing 787 is an efficient aircraft.
  - reason:   The claim does not directly relate to the context about the Concorde's economic viability and does not depend on any specific part of the context.
  - refined:  The Boeing 787 is an efficient aircraft compared to the Concorde.
- **F21** (missing_comparison)
  - baseline: The Airbus A380 is quieter.
  - reason:   The claim states 'The Airbus A380 is quieter' without the comparison target from the context.
  - refined:  The Airbus A380 is quieter compared to the Concorde.
- **F22** (missing_comparison)
  - baseline: The Boeing 787 is quieter.
  - reason:   The claim states 'The Boeing 787 is quieter' without the comparison target from the context.
  - refined:  The Boeing 787 is quieter compared to the Concorde.
- **F23** (missing_comparison)
  - baseline: The Airbus A380 is faster.
  - reason:   The claim states 'faster' without specifying a comparison target from the context.
  - refined:  The Airbus A380 is faster than the Concorde.
- **F26** (omitted_condition_or_source)
  - baseline: This limited market made the Concorde less attractive for airlines due to its ability to fly non-stop to only 18 destinations.
  - reason:   The claim omits the specific condition that the Concorde's market limitation was one of the factors rendering it uneconomical.
  - refined:  This limited market, along with the Concorde's high operating costs and other factors, made it less attractive for airlines.
- **F27** (omitted_condition_or_source)
  - baseline: Airlines were seeking profitable routes, such as those not limited to only 18 destinations.
  - reason:   The claim omits the specific context about the Concorde's limited market.
  - refined:  Airlines were seeking profitable routes, such as those not limited to only 18 destinations, making the Concorde's market limited.

## MISSING RELATIONS (word mapping -> judges)
- span `The Concorde wa` -> contingency
- span `Moreover, the introduction of more efficient, quieter, and` -> contingency
- span `coupled with increased fuel efficiency and reduced operating costs, made the Concorde's economic viability untenable` -> contingency

## ADDED FACTS
- [contingency] The Concorde's high operating costs due to its fuel consumption and maintenance, coupled with its limited market, made it uneconomical to operate.
- [contingency] the introduction of more efficient aircraft like the Airbus A380 and Boeing 787 resulted in the Concorde's uneconomical operation.
- [contingency] increased fuel efficiency and reduced operating costs made the Concorde's economic viability untenable.

## VERIFICATION BEFORE VS AFTER REFINEMENT
- F5: SUPPORTED -> CONTRADICTED
  - before: The Concorde is compared to conventional subsonic airliners.
  - after:  The Concorde consumed approximately 3 times more fuel per seat compared to conventional subsonic airliners.
- F13: UNDECIDED -> SUPPORTED
  - before: The specially designed engines and materials that added considerable weight exacerbated the Concorde's efficiency penalty.
  - after:  The specially designed engines and materials for supersonic aerodynamics added considerable weight, exacerbating the Concorde's efficiency penalty.
- F16: SUPPORTED -> UNDECIDED
  - before: More efficient aircraft like the Airbus A380 and Boeing 787 were introduced.
  - after:  More efficient aircraft like the Airbus A380 and Boeing 787 were introduced, reducing the Concorde's economic viability.
- F17: SUPPORTED -> UNDECIDED
  - before: Quieter and more efficient aircraft like the Airbus A380 and Boeing 787 were introduced.
  - after:  Quieter and more efficient aircraft like the Airbus A380 and Boeing 787 were introduced, which were more economical to operate.
- F26: UNDECIDED -> SUPPORTED
  - before: This limited market made the Concorde less attractive for airlines due to its ability to fly non-stop to only 18 destinations.
  - after:  This limited market, along with the Concorde's high operating costs and other factors, made it less attractive for airlines.

## METRICS (whole mini benchmark)

| System | Precision | Recall | F1 |
|---|---|---|---|
| Baseline | 0.5050 | 0.2812 | 0.3613 |
| VERIFACT-Lite | 0.4802 | 0.2812 | 0.3547 |
